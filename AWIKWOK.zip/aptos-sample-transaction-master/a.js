const aptos = require("aptos");
const NODE_URL = process.env.APTOS_NODE_URL || "https://fullnode.mainnet.aptoslabs.com";
const client = new aptos.AptosClient(NODE_URL);
const coinClient = new aptos.CoinClient(client);
const bip39 = require("bip39");
const { bytesToHex } = require('@noble/hashes/utils');
const fetch = require('node-fetch');
require('dotenv').config()

const APTOS_DERIVATION_PATH = "m/44'/637'/0'/0'/0'";


const getCollectionBySlug = (slug) => new Promise((resolve, reject) => {

    fetch(`https://aptos-mainnet-api.bluemove.net/api/market-items?filters[collection][slug][$eq]=${slug}&filters[status][$eq]=1&filters[price][$gte]=0&filters[price][$lte]=10000000000000000&sort[0]=price%3Aasc&pagination[page]=1&pagination[pageSize]=10000`, {
        headers: {
            'authority': 'aptos-mainnet-api.bluemove.net',
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'origin': 'https://bluemove.net',
            'referer': 'https://bluemove.net/',
            'sec-ch-ua': '"Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
        }
    }).then(res => res.json())
        .then(res => {
            resolve(res.data)
        })
        .catch(err => reject(err))
});

const getLastLaunchpad = () => new Promise((resolve, reject) => {

    fetch(`http://aptos-mainnet-api.bluemove.net/api/launchpads?filters[status][$eq]=1&sort[0]=start_time%3Aasc`, {
        headers: {
            'authority': 'aptos-mainnet-api.bluemove.net',
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'origin': 'https://bluemove.net',
            'referer': 'https://bluemove.net/',
            'sec-ch-ua': '"Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
        }
    }).then(res => res.text())
        .then(res => {
            resolve(res.data)
        })
        .catch(err => reject(err))
});

const collectionDetails = (slug) => new Promise((resolve, reject) => {

    fetch(`https://aptos-mainnet-api.bluemove.net/api/collections?filters[slug][$eq]=${slug}`, {
        headers: {
            'authority': 'aptos-mainnet-api.bluemove.net',
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'origin': 'https://bluemove.net',
            'referer': 'https://bluemove.net/',
            'sec-ch-ua': '"Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
        }
    }).then(res => res.json())
        .then(res => {
            resolve(res.data[0])
        })
        .catch(err => reject(err))
});

const getNftMintedByUser = (slug) => new Promise((resolve, reject) => {

    fetch('https://fullnode.mainnet.aptoslabs.com/v1/accounts/0xca7ef5b94893a325ddb8548b11bbc215b41d875e891c80fdc124f260aa0c940b/resource/0x8eafc4721064e0d0a20da5c696f8874a3c38967936f0f96b418e13f2a31dcf4c::factory::MintedByUser', {
        headers: {
            'authority': 'fullnode.mainnet.aptoslabs.com',
            'accept': 'application/json',
            'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'origin': 'https://bluemove.net',
            'referer': 'https://bluemove.net/',
            'sec-ch-ua': '"Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'cross-site',
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
        }
    }).then(res => res.json())
        .then(res => {
            resolve(res.data[0])
        })
        .catch(err => reject(err))
});

(async () => {
    try {

        const modulesAddress = process.env.MODULES_ADDRESS; // sample aptos wizard 0x8eafc4721064e0d0a20da5c696f8874a3c38967936f0f96b418e13f2a31dcf4c
        const typeMint = process.env.MINT_TYPE == 'public' ? 'mint_with_quantity' : 'mint_with_quantity_whitelist';

        const mnemonic = process.env.MNEMONIC;
        const normalizeMnemonics = mnemonic.trim()
            .split(/\s+/)
            .map((part) => part.toLowerCase())
            .join(" ");

        const { key } = aptos.derivePath(APTOS_DERIVATION_PATH, bytesToHex(bip39.mnemonicToSeedSync(normalizeMnemonics)));

        // your account
        const wallet = new aptos.AptosAccount(key);

        // mint launchpad
        const signerTransactionGenerate = await client.generateTransaction(wallet.address().hex(), {
            "function": `${modulesAddress}::factory::${typeMint}`,
            "type_arguments": [],
            "arguments": [
                "1" // total mint
            ],
            "type": "entry_function_payload"
        });


        const signedTx = await client.signTransaction(wallet, signerTransactionGenerate)
        const pendingTx = await client.submitTransaction(signedTx)
        await client.waitForTransaction(pendingTx.hash);
        const result = await client.getTransactionByHash(pendingTx.hash);
        console.log(pendingTx)
        console.log(result)

    } catch (e) {
        console.log(e)
    }

})();